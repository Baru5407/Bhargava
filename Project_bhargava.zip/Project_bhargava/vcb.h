#ifndef VCB_H
#define VCB_H

#include "BlocksBitmap.h"

class VCB {
public:
    VCB();
    void write(char *block);
    void read(char *block);

public:
    int blockNumber;
    int blockSize;
    int freeBlocksCoun;
    BlocksBitmap freeBlocks;
};

#endif
