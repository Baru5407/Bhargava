#ifndef FILEINFO_H
#define FILEINFO_H

//#include <string>
//using std::string;

#define FILENAME_LENGTH 16

class FileInfo {
public:
    void write(char *block);
    void read(char *block);
    void setFilename(const char *f);

public:
    char filename[FILENAME_LENGTH];
    short startBlockNumber;
    short size;
};

#endif
