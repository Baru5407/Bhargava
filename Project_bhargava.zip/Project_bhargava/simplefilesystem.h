#ifndef SIMPLEFILESYSEM_H
#define SIMPLEFILESYSEM_H

#include "vcb.h"
#include "fileinfo.h"
#include "fcb.h"

#include <vector>
using std::vector;

#define FILENAME_TOO_LONG 1
#define NO_ENOUGH_CONTIGOUS_SPACE 2
#define FILE_COUNT_EXCEDED 3

class SimpleFileSystem {
public:
    static char *block;
    static bool IsFirstRun;
    static vector<FCB *> openFiles;

public:
    SimpleFileSystem();
    void dumpToDisk();
    void printOpenFiles();

   int create(char *filename, short size);
   FCB *open(char *filename);
   void close(FCB *fcb);
   int write(FCB *fcb, char *data, int length = -1);
   void read(FCB *fcb, char *data, int length = -1);
   void dir();
   void deleteFile(char *filename);

public:
    VCB *vcb;

};

#endif
