#ifndef BLOCKSBITMAP_H
#define BLOCKSBITMAP_H

#define BITS_PER_WORD 8

#define WORD_OFFSET(b) ((b) / BITS_PER_WORD)
#define BIT_OFFSET(b)  ((b) % BITS_PER_WORD)

class BlocksBitmap {
public:
    BlocksBitmap();
    void setBit(int i);
    void clearBit(int i);
    bool getBit(int i);
    inline int getBitsCount() { return 512; }
    void write(char *block);
    void read(char *block);
    int getChunk(int size_in_blocks);

private:
    char bits[64];
};

#endif
