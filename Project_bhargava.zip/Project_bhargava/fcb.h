#ifndef FCB_H
#define FCB_H

class FCB {
public:
    short size;
    short firstDataBlock;
};

#endif
