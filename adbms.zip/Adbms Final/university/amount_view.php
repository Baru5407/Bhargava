<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
    
     <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
	  <script src="js/canvasjs.min.js"></script>
	  
	  </head>
      
  <style>
td{padding:100px;  height:50px;}
</style>
</head>

<body><div class="container-fluid">
<?php
include('main_header.php');

?>
<a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; position: absolute;"> </a>    <br><br><br>
<div class='col-md-8 col-md-offset-2' id="form" style="margin-bottom:10px;" >

<?php
$result1 = mysqli_query($conn,"SELECT * FROM Organizer");
$result2 = mysqli_query($conn,"SELECT * FROM seat");
$result3= mysqli_query($conn,"SELECT SUM(amount) FROM hotel");
$result4= mysqli_query($conn,"SELECT * FROM event WHERE name='Education Fair'");
$row4 = $result4->fetch_assoc();

$result5= mysqli_query($conn,"SELECT * FROM event WHERE name='Manage Seating'");
$row5 = $result5->fetch_assoc();

$result6= mysqli_query($conn,"SELECT * FROM event WHERE name='Restaurant'");
$row6 = $result6->fetch_assoc();


$edu_b=$row4['event_but'];
$edu_e=$row4['exp'];
$seat_b=$row5['event_but'];
$seat_e=$row5['exp'];
$hotal_b=$row6['event_but'];
$hotal_e=$row6['exp'];
$sum_b=$edu_b+$seat_b+$hotal_b;
$sum_e=$edu_e+$seat_e+$hotal_e;
 
$row1 = $result1->fetch_assoc();
$row2 = mysqli_fetch_array($result2);
$row3 = mysqli_fetch_array($result3);
$e= $result1->num_rows;
  $edu =$e*5;
  $s= $result2->num_rows;
  $seat =$s*5;      

$hotel=$row3['SUM(amount)'];

$gt=$edu+$seat+$hotel;

$mydata2[] =array( "y" => $edu,"label"=>'Education Fair');
$mydata2[] =array( "y" => $seat,"label"=>'Manage Seating');
$mydata2[] =array( "y" => $hotel,"label"=>'Restaurant');
    ?>


 <table class='table' style="margin-top:50px;">  

   <tr> <th colspan='4' style="text-align:center;"><h3>Total Amount Slip</h3></th></tr>
<tr><th>EVENT</th><th>Income Amount </th> <th>Budget Amount</th> <th>Expenses Amount</th></tr>
<tr><th>Total Amount From Eduction Fair</th><td> <?=$edu?>    </td><td> <?=$edu_b?>    </td><td> <?=$edu_e?>     </td></tr>

<tr><th>Total Amount  From Manage Seating</th><td> <?=$seat?>    </td> <td> <?=$seat_b?>    </td><td> <?=$seat_e?>     </td> </tr>

<tr><th>Total Amount From Restaurant</th><td><?=$hotel?> </td> <td> <?=$hotal_b?>    </td><td> <?=$hotal_e?>     </td> </tr>

<tr><th>Grand Total</th>  <th><?=$gt?> </th> <th> <?=$sum_b?>    </th><th> <?=$sum_e?>     </th></tr>
  

</table>



</div>


<div class="row">
<div class="col-md-3">
			</div>
			<div class="col-md-6" style="border: 1px solid grey">
			
				<form action="" method="POST">
				<h2>Change Graph</h2>
				<table class="table">
					<tr><td><select name="graph" id="graph" class="form-control">
						<option value="">Select Chart</option>
						<option value="pie">Pie Chart</option>
						<option value="line">Line Chart</option>
						<option value="bar">Bar Chart</option>
						<option value="doughnut">Doughnut Chart</option>
						<option value="spline">Spline Chart</option>
					</select></td><td>
					<input type="button" onclick="change_garph(graph.value)" class="btn btn-primary" name="get_graph" value="Search	">
					</td>
				</tr></table>
				</form>
			</div>
				<div class="col-md-1">
			</div>
			 
			</center>
		</div>
		
	
	
		<div class="container" ><br><br>
		 <?php 
		
		$r1=$conn->query("Select * from event");
		$num=$r1->num_rows;
			while($r=$r1->fetch_assoc())
		{
			
		$mydata[] =array( "y" => $r['exp'],"label"=>$r['name']);
		$mydata1[] =array( "y" => $r['event_but'],"label"=>$r['name']);
		}
	

    ?>	
	<div id="chartContainer2" style="height: 600px; width: 100%;"></div>
				<br>
				<div id="chartContainer" style="height: 500px; width: 100%;"></div>
					<br>
					<div id="chartContainer1" style="height: 500px; width: 100%;"></div>

			
	
		</div>
		
        <script type="text/javascript">
			var gr="bar";
			var gr1="bar";
	
		
	
			 function setGarph2(){
		 var chart = new CanvasJS.Chart("chartContainer2", {
                    theme: "theme1",
                    animationEnabled: true,
                    title: {
                        text: "Graph For Event Income"
                    },
					axisX: {
        title:"EVENT NAME",
       maximum: <?=$num?>
      },
      axisY: {
        title:"EVENT INCOME"
      },

      legend:{
        verticalAlign: "bottom",
        horizontalAlign: "left"

      },
                    data: [
                    {
                        type: gr,                
                        dataPoints: <?php echo json_encode($mydata2, JSON_NUMERIC_CHECK); ?>
                    }
                    ]
                });
                chart.render();
		}
		
		
			 function setGarph1(){
		 var chart = new CanvasJS.Chart("chartContainer1", {
                    theme: "theme3",
                    animationEnabled: true,
                    title: {
                        text: "Graph For Event Expenses"
                    },
					axisX: {
        title:"EVENT NAME",
       maximum: <?=$num?>
      },
      axisY: {
        title:"EVENT EXPENSES"
      },

      legend:{
        verticalAlign: "bottom",
        horizontalAlign: "left"

      },
                    data: [
                    {
                        type: gr,                
                        dataPoints: <?php echo json_encode($mydata, JSON_NUMERIC_CHECK); ?>
                    }
                    ]
                });
                chart.render();
		}
		
		
		
		
			
           
			 function setGarph(){
		 var chart = new CanvasJS.Chart("chartContainer", {
                    theme: "theme1",
                    animationEnabled: true,
                    title: {
                        text: "Graph For Event Budget"
                    },
					axisX: {
        title:"EVENT NAME",
       maximum: <?=$num?>
      },
      axisY: {
        title:"EVENT BUDGET"
      },

      legend:{
        verticalAlign: "bottom",
        horizontalAlign: "left"

      },
                    data: [
                    {
                        type: gr1,                
                        dataPoints: <?php echo json_encode($mydata1, JSON_NUMERIC_CHECK); ?>
                    }
                    ]
                });
                chart.render();
		}
		
	
		function change_garph(graph){
			
			if(graph.length==0){
				document.getElementById('graph').style.borderColor='red';
				
			}else{
				gr=graph;
				gr1=graph;
			  setGarph();
			  setGarph1();
			  setGarph2();
			  document.getElementById('graph').style.borderColor='darkgray';
			
			}
			
		}
			
            $(function () {
               setGarph();
               setGarph1();
               setGarph2();
            });
        </script>
		</div>
    </body>
 <style>
 .canvasjs-chart-credit {
   display: none;
}
 </style>
</html>
 

