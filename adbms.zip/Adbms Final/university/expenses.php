<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] )){
header("location:index.php");
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>
<div class="container">
<a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; position: absolute;"> </a>    <br><br><br>
	<div class="row">
		<div class="col-md-4">
		</div>
		<div class="col-md-4" style="margin-top:100px">
			<form action="" method="POST">
			<h2>Update Event Expenses</h2><br>
			
			<select name="e_id" required class="form-control"><option value="" selected disabled>Select Event</option>
			<?php 
			$qry="Select * FROM event";
			$q=$conn->query($qry);
			while($r=$q->fetch_assoc()){?>
			<option value="<?=$r['event_id']?>"><?=$r['name']?></option>
			<?php }?>
			</select><br>
		<input type="number" class="form-control" name="exp"  required placeholder="Total EEXPENSES"><br>
				<br><center>
			<input type="submit" name="event1" class="btn btn-primary" value="Create Event"></center>
			
			
			</form>
		</div>
		<div class="col-md-4">
		</div>
	</div>
<?php if(isset($_POST['event1'])){
	$ex=$_POST['exp'];
	$id=$_POST['e_id'];
$sql="Update  event set exp='$ex' WHERE event_id='$id'";
$r=$conn->query($sql);
if($r===TRUE){
	header("location:main.php");
	
}
}?>

</div>
</body>
</html>
<?php } ?>