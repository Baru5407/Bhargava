<header style="    background: #017ba4;
    color: white">
	  <div class="container">
	  <div class="row">
	  <div class="col-md-9">
		<h2><strong>University Fair </strong></h2>
		</div>
		<div class="col-md-3" style="text-align:right;">
			</div>
		</div>
		</div>
	  </header>
	  