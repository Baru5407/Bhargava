<?php
include('connection.php'); 
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>
<html>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}
#f{
	width:50%;
	background-color:#ccc;
}

</style>

<a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; position: absolute;"> </a>

<div id="f" class="col-md-offset-3">


<?php

  if(isset($_POST['sub']))
{
    $sql = "INSERT INTO hotel (Type_Of_Participant,Customers,Payment,Amount,Customer_info,Menu,Location,Discount)
    VALUES ('".$_POST["type_of_participant"]."','".$_POST["name"]."','".$_POST["payment"]."','".$_POST["amount"]."','".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["diseases"]."','".$_POST["contact"]."')";

   // $result = mysqli_query($conn,$sql);
   $r=$conn->query($sql);
 //header('Location:view_edu.php');
 if($r){
 ?>
 <h3>Participant Slip</h3>
<table class="table">
 <tr><td>Type Of Participant</td><td><?=$_POST["type_of_participant"]?></td></tr>
  <tr><td>Participant Name</td><td><?=$_POST["name"]?></td></tr>
   <tr><td>Type Of Payment</td><td><?=$_POST["payment"]?></td></tr>
    <tr><td>  Amount</td><td><?=$_POST["amount"]?></td></tr>
     <tr><td>Participant Detail</td><td><?=$_POST["fname"]?></td></tr>
      <tr><td>Menu Being Displayed</td><td><?=$_POST["lname"]?></td></tr>
        <tr><td>Location And Venue</td><td><?=$_POST["diseases"]?></td></tr>
          <tr><td>Discount Provided  </td><td><?=$_POST["contact"]?></td></tr>
         
 </table>







 <?php

}else{
  ?>
 <h3>Sorry</h3>
 <?php
 }
}else{?>
<form action="" method="POST">
  <h3 style="padding:17px;">Form For the Restaurant</h3>

  <label for="lname" >Type of Participant</label>
   
  
  <select name="type_of_participant">
    <option >Organizer</option>
	 <option >Student</option>
	 <option >Customer</option>
    <option>Other</option>
   
    </select><br>
 <label for="fname">Participant Name</label>
    <input type="text" id="name" name="name" placeholder="Participant Name" required  >
   
     <label for="lname">Type of Payment</label>
 <select name="payment">
    <option value="Cheque">Cheque</option>
    <option value="Cash">Cash</option>
    <option value="Net Banking">Net Banking</option>
    <option value="Debit/Credit Card">Debit/Credit Card</option>
    </select><br>
 <label for="fname">Amount</label>
    <input type="number" id="nme" class="form-control" name="amount" placeholder="Fill The Amount"  required>
	
    <label for="fname">Participant Detail</label>
    <input type="text" id="fname" name="fname" placeholder="Participant Detail"  required>

    <label for="lname">Menu Being Displayed</label>
    <input type="text" id="lname" name="lname" placeholder="Menu Being Displayed" required >
<label for="fname">Location and Venue</label>
     <input type="text" id="room" name="diseases" placeholder="Location and Venue"required >
	
	<label for="fname">Discount provided</label>
    <input type="number" id="room" class="form-control"  name="contact" placeholder="Discount provided"required >
		<input type="submit" name="sub" value="Submit">
 
  </form>
<?php }?>

</div>
</body>
</html>
