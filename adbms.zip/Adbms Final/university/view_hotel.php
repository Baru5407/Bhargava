<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
	  <script src="js/canvasjs.min.js"></script>
  
</head>
<body>
<?php
include('main_header.php');

?>
<a href="main.php"><input type="button" class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; position: absolute;"> </a>
<br>
<div class='col-md-8 col-md-offset-2' id="form">
<!--form action="search_hotel.php" method="POST">
<input type="text" Placeholder="Search" name="search">
<input type="submit" value="search" name="sub">
</form-->

<?php
$result = mysqli_query($conn,"SELECT * FROM hotel");
echo "<table class='table'>
<tr>

<th> Type Of Participant</th>

<th>Participant Name</th>
<th>Payment_Type</th>
<th>Amount</th>
<th>Customer Info</th>
<th>Menu Being Displayed</th>
<th>Location and Venue</th>
<th>Discount provided</th>
<th>Delete</th>
<th>Update</th>
</tr>";
  $_SESSION['total_amt']= 0;
  $num=$result->num_rows;
while($row = mysqli_fetch_array($result))
  {
     echo "<tr>";
     echo "<td>" . $row['Type_Of_Participant'] . "</td>";
    echo "<td>" . $row['Customers'] . "</td>";
     echo "<td>" . $row['Payment'] . "</td>";
      echo "<td>" . $row['Amount'] . "</td>";

     echo "<td>" . $row['Customer_info'] . "</td>";
    echo "<td>" . $row['Menu'] . "</td>";
     echo "<td>" . $row['Location'] . "</td>";   
     echo "<td>" . $row['Discount'] . "</td>"; 
	$mydata1[] =array( "y" => $row['Amount'],"label"=>$row['Customers']);

    ?>
<td><a href="delete_hotel.php?id=<?=$row['id']?>">Delete</a></td>
<td><a href="Update_hotel.php?id=<?=$row['id']?>">Update</a></td>


  <?php
  echo "</tr>";
  $_SESSION['total_amt']=  $_SESSION['total_amt'] +  $row['Amount'] ;

  }
 
  ?>
<tr><td  colspan="3"> <b>Total  </b></td><td  > <b style="color:blue;"> <?php echo $_SESSION['total_amt']?> </b> </td> </tr>
</table>



</div>

	<div class="container-fluid">
	<br>
	<div class="row" ><center>
	
		
			
			
				
			</div>
			<div class="col-md-3">
			</div>
			<div class="col-md-6" style="border: 1px solid grey">
			
				<form action="" method="POST">
				<h2>Change Graph</h2>
				<table class="table">
					<tr><td><select name="graph" id="graph" class="form-control">
						<option value="">Select Chart</option>
						<option value="pie">Pie Chart</option>
						<option value="line">Line Chart</option>
						<option value="bar">Bar Chart</option>
						<option value="doughnut">Doughnut Chart</option>
						<option value="spline">Spline Chart</option>
					</select></td><td>
					<input type="button" onclick="change_garph(graph.value)" class="btn btn-primary" name="get_graph" value="Search	">
					</td>
				</tr></table>
				</form>
			</div>
				<div class="col-md-1">
			</div>
			 
			</center>
		</div>
		
	
	
		<div class="container" ><br><br>
	
		<div class="container" ><br><br>
		 <?php 
		
		$r1=$conn->query("Select * from event where name='Restaurant'");
		
		$r=$r1->fetch_assoc();
		
			
		$mydata2[] =array( "y" => $r['event_but'],"label"=>'Budget');
		$mydata2[] =array( "y" => $r['exp'],"label"=>'Expenses');
		
	

    ?>
			<div id="chartContainer1" style="height: 500px; width: 100%;"></div>
			<br>
			
			<div id="chartContainer" style="height: 500px; width: 100%;"></div>
		</div>
		
        <script type="text/javascript">
			var gr="spline";
			var gr1="bar";
	
		
	
			 function setGarph1(){
		 var chart = new CanvasJS.Chart("chartContainer", {
                    theme: "theme3",
                    animationEnabled: true,
                    title: {
                        text: "Graph Restaurant Report"
                    },
					axisX: {
        title:"Name Customers",
       maximum: <?=$num?>
      },
      axisY: {
        title:"Payment"
      },

      legend:{
        verticalAlign: "bottom",
        horizontalAlign: "left"

      },
                    data: [
                    {
                        type: gr,                
                        dataPoints: <?php echo json_encode($mydata1, JSON_NUMERIC_CHECK); ?>
                    }
                    ]
                });
                chart.render();
		}
		
		
		
		
		
			 function setGarph2(){
		 var chart = new CanvasJS.Chart("chartContainer1", {
                    theme: "theme3",
                    animationEnabled: true,
                    title: {
                        text: "Graph Restaurant Expenses and Budget"
                    },
					axisX: {
        title:"",
       maximum:2
      },
      axisY: {
        title:"Amount"
      },

      legend:{
        verticalAlign: "bottom",
        horizontalAlign: "left"

      },
                    data: [
                    {
                        type: gr1,                
                        dataPoints: <?php echo json_encode($mydata2, JSON_NUMERIC_CHECK); ?>
                    }
                    ]
                });
                chart.render();
		}
		
		
		
			
           
			
	
		function change_garph(graph){
			
			if(graph.length==0){
				document.getElementById('graph').style.borderColor='red';
				
			}else{
				gr=graph;
				gr1=graph;
			 
			  setGarph1();
			  setGarph2();
			  document.getElementById('graph').style.borderColor='darkgray';
			
			}
			
		}
			
            $(function () {
              
               setGarph1();
               setGarph2();
            });
        </script>
		</div>
    </body>
 <style>
 .canvasjs-chart-credit {
   display: none;
}
 </style>
</html>
 