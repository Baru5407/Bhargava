<?php 
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");

include('connection.php');


$sql = "UPDATE organizer SET organizer='".$_POST["eid"]."',profession='".$_POST["fname"]."',staff_drecting='".$_POST["lname"]."',Loactaion='".$_POST["contact"]."',Document='".$_POST["email"]."',Date='".$_POST["pname"]."' WHERE
id='".$_GET['id']."'";
$res=$conn->query($sql);
	
if($res===TRUE){
	header('Location:view_edu.php');
	echo $sql;
}
else
{
echo $sql.''.$conn->error;

}
$conn->close();
?>