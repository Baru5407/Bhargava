 <header style="background: #017ba4;
    color: white">
	  <div class="container">
	  <div class="row">
	  <div class="col-md-9">
		<h2><strong>University Fair </strong></h2>
		</div>
		<div class="col-md-3" style="text-align:right;">
		<h3><strong> <?php echo $_SESSION['u_name'];?> <a href="Logout.php" class="btn" role="button"><h1 style="color:#fff;font-size: 25px; margin-top: 6px">logout</h1></a></strong></h3>
		</div>
		</div>
		</div>
	  </header>
	  
	  
	  