<?php 
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<style>
.btn-block {
    display: block;
    width: 100%;
    margin-bottom: 40px;
</style>
  <body style="width: 100%;
    height: 400px;
    background-image: url('img/bck.jpg');
    background-size: 100% 100%;
    ">
<?php
include('main_header.php');

?>
<div class="container-fluid" style="margin-top:30px">
	


	
	
  <div class="row"  >

   <div class="col-md-4" style="width: 200px;
    margin-right: 113px;
    margin-left: 78px;" >

<a href="edu.php" class="btn btn-default btn-block" role="button" ><div id="leftBtn">Register organizer</div></a>   

<a href="view_edu.php" class="btn btn-default btn-block" role="button"><div id="leftBtn">Organizer list</div></a>
<a href="seat.php" class="btn  btn-default btn-block" role="button"><div id="leftBtn">Register student</div></a>  
<a href="view_seat.php" class="btn  btn-default btn-block" role="button"><div id="leftBtn">Show seating</div>
</a> 
<a href="hotel.php" class="btn btn-default btn-block" role="button"><div id="leftBtn">Add Restaurant info</div></a>
<a href="view_hotel.php" class="btn btn-default btn-block" role="button"><div id="leftBtn">Restaurant Report</div></a>

	</div>

	   <div class="col-md-4" >
	 
	<a href="budget.php" class="btn btn-default btn-block" role="button" style=" padding: 30px;"><div id="leftBtn" style="   font-size: 35px; color: rgba(0, 0, 0, 0.48);">Update your budget</div></a> 
  
   

   </div> 
      <div class="col-md-4" >

<a href="expenses.php" class="btn btn-default btn-block" role="button" style=" padding: 30px;"><div id="leftBtn" style="   font-size: 35px; color: rgba(0, 0, 0, 0.48); margin-left: -21px;"> Update your expenses</div></a>    



	</div>     
	<div class="col-md-8" >

 <a href="amount_view.php" class="btn btn-default btn-block" role="button" style=" padding: 30px;" ><div id="leftBtn"    style="   font-size: 35px; color: rgba(0, 0, 0, 0.48);">Total amount with final graph</div></a> 



</div>

	</div>
	
   </div>


  


    
  </div>


</body>
</html>
