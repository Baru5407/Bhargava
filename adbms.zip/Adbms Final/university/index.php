<?php
   ob_start();
   session_start();
   
 
?>

<html lang = "en">
   
   <head>
   
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
   </head>
	
   <body style="width: 100%;
    height: 400px;
    background-image: url('img/bck.jpg');
    background-size: 100% 100%;">
	
        <?php
include("header.php");
	  ?>
	  <br>
	  <br>
	  <br>
	  <div class="container">
	  <div class="row">
	  <div class="col-md-6 col-md-offset-3" id="login">
      <h2>ADMIN LOGIN</h2> 
      
      
         <form class = "form-signin" action="login1.php" method = "post">
           <h2>Enter Username and Password</h2> 
            <input type = "text" class = "form-control" id="user_name" name="username" placeholder = "username" 
               required autofocus></br>
			  
            <input type = "password" class="form-control" id="login_password"  name = "password" placeholder = "password" required>
			<br>
            <button class = "btn  btn-primary btn-block" type="submit" name ="sub">Login</button>
         </form>
			
        
         
      </div> 
      </div> 
      </div> 
	  
	  <?php 
	  include('footer.php');
	  ?>
      
   </body>
</html>