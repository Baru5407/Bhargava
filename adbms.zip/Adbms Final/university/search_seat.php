<html>
<head>
<style>
table
{
border-style:solid;
border-width:2px;
border-color:pink;
}
</style>
</head>
<body bgcolor="#EEFDEF">
<a href="Logout.php" class="btn btn-info" role="button">logout</a>
<?php

include('connection.php');
if(isset($_POST['sub']))
{  
      $search_text=$_POST['search'];
	  $searchq=preg_replace('/[^^a-zA-Z0-9#@:_(),.!@"\/ ]/','',$search_text); 
      
        
$sql="SELECT * FROM seat WHERE 	Participant LIKE '%".$searchq."%' OR Profession LIKE '%".$searchq."%' OR Participant_Information LIKE '%".$searchq."%' OR Staff_Directing LIKE '%".$searchq."%' OR Location LIKE 
'%".$searchq."%' OR Document LIKE '%".$searchq."%'OR Date LIKE '%".$searchq."%' OR Row_No LIKE '%".$searchq."%'";
if ($result=mysqli_query($conn,$sql))
{
                                                                                                                
echo "<table border='1'>
<tr>
<th>Participant</th>
<th>Profession</th>
<th>Participant Information</th>
<th>Staff Directing Participants</th>
<th>Location and Venue</th>
<th>Document To participant</th>
<th>Date and time</th>
<th>Row No. And Seat No</th>


</tr>";
 
  
 while ($row=mysqli_fetch_row($result))
  {
  echo "<tr>";

  echo "<td>" . $row['1'] . "</td>";
  echo "<td>" . $row['2'] . "</td>";
  echo "<td>" . $row['3'] . "</td>";
  echo "<td>" . $row['4'] . "</td>";
  echo "<td>" . $row['5'] . "</td>";
  echo "<td>" . $row['6'] . "</td>";
  echo "<td>" . $row['7'] . "</td>";
  echo "<td>" . $row['8'] . "</td>";



  echo "</tr>";
  }
  
echo "</table>";
 mysqli_free_result($result);
  }
}
mysqli_close($conn);
?>
</body>
</html>