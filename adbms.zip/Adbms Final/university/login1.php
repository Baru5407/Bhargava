<?php
session_start();
include('connection.php');
$username = $_POST['username'];
$password = $_POST['password'];
 $_SESSION['u_name'] = $_POST['username'];

// Check connection
$qz = "SELECT username FROM admin where username='".$username."' and password='".$password."'" ; 
$qz = str_replace("\'","",$qz); 
$result = mysqli_query($conn,$qz);
if($result->num_rows>0){
  
  header('Location:main.php');
 
}else{
	  header('Location:./');
	
}

?>