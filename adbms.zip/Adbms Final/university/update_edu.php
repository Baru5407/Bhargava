<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>








<!DOCTYPE html>
<html>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
 
}
</style>
<body>



<div style="   width: 50%;
    margin: 70 auto;
    border: 1px solid #ccc;
    padding: 24px;
    background-color: #ccc; >                                                    ">
  <form action="" method="POST">
  <h3 style="text-align: center">Form For the Organizers</h3>
<?php 
if(isset($_GET['id'])){
 $id=  $_GET['id'] ;
 $qry="SELECT * FROM Organizer WHERE id ='$id' ";
 $q=$conn-> query($qry); 
 $r=$q-> fetch_assoc();
 ?>
  
   <label for="fname">Organizer Name</label>
    <input type="text" id="eid" name="eid" value="<?=$r['organizer']?>"      placeholder="Organizer Name" >
	
    <label for="fname">Profession</label>
    <input type="text" id="fname" name="fname"     value="<?=$r['profession']?>"  placeholder="Profession"  >

    <label for="lname">Staff Directing Organizer</label>
    <input type="text" id="lname" name="lname"  value="<?=$r['staff_drecting']?>"      placeholder="Staff Directing Organizer" >
	
	<label for="fname">Loactaion And Vanue</label>
    <input type="text"  name="contact"  value="<?=$r['Loactaion']?>"    placeholder="Loactaion And Vanue " >
	
	<label for="fname">Document To Organizer</label>
    <input type="text"  name="email"  value="<?=$r['Document']?>"     placeholder="Document To Organizer ">
     
	  <label for="lname">Date and time</label>
    <input type="text" name="pname"  value="<?=$r['Date']?>"   placeholder="Date and time">
	
	
    <input type="submit" name="sub_update" value="Submit">
  </form>
  <?php }?>
</div>

</body>
</html>


<?php 
if(isset($_POST['sub_update'])){
 







$sql = "UPDATE organizer SET organizer='".$_POST["eid"]."',profession='".$_POST["fname"]."',staff_drecting='".$_POST["lname"]."',Loactaion='".$_POST["contact"]."',Document='".$_POST["email"]."',Date='".$_POST["pname"]."' WHERE
id='".$_GET['id']."'";
$res=$conn->query($sql);
	
if($res===TRUE){
	header('Location:view_edu.php');
	
}
else
{
echo $sql.''.$conn->error;

}
$conn->close();}
?>
