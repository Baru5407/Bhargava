<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>


<!DOCTYPE html>
<html>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 20%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #3ec8d4;
   
}
</style>
<body>

<h3 style="text-align:center;">Update Participant Seat Allocation</h3>

<div style="    border-radius: 5px;
    padding: 20px;
    width: 50%;
    margin: 0 auto;
    background-color: #ccc;">

<?php 
if(isset($_GET['id'])){
 $id=  $_GET['id'] ;
 $qry="SELECT * FROM seat WHERE id ='$id' ";
 $q=$conn-> query($qry); 
 $r=$q-> fetch_assoc();
 ?>







  <form action="" method="POST">
  
   <label for="fname">Participant</label>
    <input type="text" id="eid" name="eid"  value="<?=$r['Participant']?>"  placeholder="Participant "required >
	
    <label for="fname">Profession</label>
    <input type="text" id="fname" name="fname" value="<?=$r['Profession']?>"  placeholder="Profession" required >

    <label for="lname">Participant Information</label>
    <input type="text" id="lname" name="lname"  value="<?=$r['Participant_Information']?>"     placeholder="Participant Information" required>
	
	<label for="fname">Staff Directing Participants</label>
    <input type="text"  name="contact"    value="<?=$r['Staff_Directing']?>" placeholder="Staff Directing Participants" required>
	
	<label for="fname">Location and Venue</label>
    <input type="text"  name="email" value="<?=$r['Location']?>"placeholder="Location and Venue "required>
     
	  <label for="lname">Document To participant</label>
    <input type="text" name="pname"   value="<?=$r['Document']?>" placeholder="Document To participant"required>
	 <label for="lname">Date and time</label>
    <input type="text" name="date11"  value="<?=$r['Date']?>"placeholder=" Date and time"required>
	
	 <label for="lname">Row No. And Seat No.</label>
    <input type="text" name="row"   value="<?=$r['Row_No']?>" placeholder="Row No. And Seat No."required>
	

	
    <input type="submit" name="sub1" value="Submit">
  </form>
  <?php }?>
</div>

</body>
</html>
<?php 
if(isset($_POST['sub1'])){
$sql = "UPDATE seat SET Participant='".$_POST["eid"]."',Profession='".$_POST["fname"]."',Participant_Information='".$_POST["lname"]."',Staff_Directing='".$_POST["contact"]."',Location='".$_POST["email"]."',Document='".$_POST["pname"]."',Date='".$_POST["date11"]."',Row_No='".$_POST["row"]."' WHERE
id='".$_GET['id']."'";
$res=$conn->query($sql);
	
if($res===TRUE){
header('Location:view_seat.php');
	
}
else
{
echo $sql.''.$conn->error;

}
$conn->close();
}
?>

