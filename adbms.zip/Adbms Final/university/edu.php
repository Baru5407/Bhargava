<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>
<div class="container-fluid">


 
 <a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px;"> </a>

<div class='row'><br>
 <div class='col-md-4 col-md-offset-4' >

<div id='form'>

    
  
  <?php

  if(isset($_POST['sub1']))
{
    $sql = "INSERT INTO organizer (e_id,e_time,organizer,profession,staff_drecting,Loactaion,Document,Date)
    VALUES ('".$_POST["ptime"]."','".$_POST["eid"]."','".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["contact"]."','".$_POST["org"]."','".$_POST["pname"]."')";

   // $result = mysqli_query($conn,$sql);
   $r=$conn->query($sql);
 //header('Location:view_edu.php');
 if($r){
 ?>
 <h3>Success</h3>
 <table class="table">
 <tr><td>Organizer Name</td><td><?=$_POST["eid"]?></td></tr>
  <tr><td>Profession</td><td><?=$_POST["fname"]?></td></tr>
   <tr><td>Staff Directing Organizer</td><td><?=$_POST["lname"]?></td></tr>
    <tr><td>Loactaion And Vanue</td><td><?=$_POST["contact"]?></td></tr>
     <tr><td>Time For Organizer speech</td><td><?=$_POST["org"]?></td></tr>
      <tr><td>Time</td><td><?=$_POST["ptime"]?></td></tr>
	  <tr><td>Date</td><td><?=$_POST["pname"]?></td></tr>
 </table>
 <?php
 }else{	echo $conn->error;
  ?>
 <h3>Sorry</h3>
 <?php
 }
}else{?>
<h3>Form For the Organizers</h3><br>
<form action="" method="POST">
  
   <label for="fname">Organizer Name</label>
    <input type="text" class='form-control' id="eid" name="eid" placeholder="Organizer Name"required >
	
    <label for="fname">Profession</label>
    <input type="text" class='form-control' id="fname" name="fname" placeholder="Profession" required >

    <label for="lname">Staff Directing Organizer</label>
    <input type="text" class='form-control' id="lname" name="lname" placeholder="Staff Directing Organizer" required>
	
	<label for="fname">Loactaion And Vanue</label>
    <input type="text" class='form-control'  name="contact" placeholder="Loactaion And Vanue" required>
	
	<label for="fname">Time For Organizer speech</label>
    <input type="text" class='form-control'  name="org" placeholder="Time For Organizer speech"required>
     
	  <label for="lname">Time</label>
    <input type="text" class='form-control'  name="ptime" placeholder="Time"required><br>

	<label for="lname">Date and time</label>
    <input type="text" class='form-control'  name="pname" placeholder="yyyy-mm-dd"required><br>
	
    <input type="submit" class='btn btn-primary' name="sub1" value="Submit">
<br>
<hr>


  </form>

<?php }?>
</div>
</div>
</div>
</div>


</body>
</html>
