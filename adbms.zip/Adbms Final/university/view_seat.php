<?php 
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>
<html>
<style>





#f{
	width:100%;
	background-color:#ccc;
}

</style>
<a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; margin-bottom:10px;"> </a>
<center>
<div id="f" >

<form action="search_seat.php" method="POST">
<input type="text" Placeholder="Search" name="search" style="width: 57%;
    padding: 7px">
<input type="submit" value="search" name="sub">
</form>
<?php
$result = mysqli_query($conn,"SELECT * FROM seat");
echo "<table class='table'>
<tr>
<th>Participant</th>
<th>Profession</th>
<th>Participant Information</th>
<th>Staff Directing Participants</th>
<th>Location and Venue.</th>
<th>Document To participant</th>
<th>Date and time</th>
<th>Row No. And Seat No.</th>
<th>Delete</th>
<th>Update</th>
</tr>";

while($row = mysqli_fetch_array($result))
  {
     echo "<tr>";
    echo "<td>" . $row['Participant'] . "</td>";
     echo "<td>" . $row['Profession'] . "</td>";
     echo "<td>" . $row['Participant_Information'] . "</td>";
    echo "<td>" . $row['Staff_Directing'] . "</td>";
     echo "<td>" . $row['Location'] . "</td>";
    echo "<td>" . $row['Document'] . "</td>";
     echo "<td>" . $row['Date'] . "</td>";
    echo "<td>" . $row['Row_No'] . "</td>";
    ?>
<td><a href="delete_seat.php?id=<?=$row['id']?>">Delete</a></td>
<td><a href="update_seat.php?id=<?=$row['id']?>">Update</a></td>


  <?php
  echo "</tr>";
  }
echo "</table>";

mysqli_close($conn);
?>
</div></div>