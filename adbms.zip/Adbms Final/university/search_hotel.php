<?php
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>
<html>
<head>
<style>
table
{
border-style:solid;
border-width:2px;
border-color:pink;
}
</style>
</head>
<body bgcolor="#EEFDEF">

<a href="Logout.php" class="btn btn-info" role="button">logout</a>
<?php
include('connection.php');
if(isset($_POST['sub']))
{  
      $search_text=$_POST['search'];
	  $searchq=preg_replace('/[^^a-zA-Z0-9#@:_(),.!@"\/ ]/','',$search_text); 
      
        
$sql="SELECT * FROM hotel WHERE Customers LIKE '%".$searchq."%' OR Payment LIKE '%".$searchq."%' OR Customer_info LIKE '%".$searchq."%' OR Menu LIKE '%".$searchq."%' OR Location LIKE 
'%".$searchq."%' OR Discount LIKE '%".$searchq."%'";
if ($result=mysqli_query($conn,$sql))
{
                                                                                                                
echo "<table border='1'>
<tr>
<th>Customers</th>
<th>Type of Payment</th>
<th>Customer_info </th>
<th> Menu Being Displayed </th>
<th>Location and Venue</th>
<th>Discount provided</th>



</tr>";
 
  
 while ($row=mysqli_fetch_row($result))
  {
  echo "<tr>";

  echo "<td>" . $row['1'] . "</td>";
  echo "<td>" . $row['2'] . "</td>";
  echo "<td>" . $row['3'] . "</td>";
  echo "<td>" . $row['4'] . "</td>";
  echo "<td>" . $row['5'] . "</td>";
  echo "<td>" . $row['6'] . "</td>";




  echo "</tr>";
  }
  
echo "</table>";
 mysqli_free_result($result);
  }
}
mysqli_close($conn);
?>
</body>
</html>