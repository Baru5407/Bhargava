 <?php
  include
 ('connection.php'); ?>
<!Doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="description" content="$1">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="style.css">

<title>University</title>


</head>
<body>
<p>Ashu</p>
 <?php

  if(isset($_POST['sub1']))
{
    $sql = "INSERT INTO seat (Participant,Profession,Participant_Information,Staff_Directing,Location,Document,Date,Row_No)
    VALUES ('".$_POST["eid"]."','".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["contact"]."','".$_POST["email"]."','".$_POST["pname"]."','".$_POST["date11"]."','".$_POST["row"]."')";

   // $result = mysqli_query($conn,$sql);
   $r=$conn->query($sql);
 header('Location:view_seat.php');
}