<?php
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>
<a href="Logout.php" class="btn btn-info" role="button">logout</a>
<html>
<head>
<style>
table
{
border-style:solid;
border-width:2px;
border-color:pink;
}
</style>
</head>
<body bgcolor="#EEFDEF">
<?php

include('connection.php');
if(isset($_POST['sub']))
{  
      $search_text=$_POST['search'];
	  $searchq=preg_replace('/[^^a-zA-Z0-9#@:_(),.!@"\/ ]/','',$search_text); 
      
        
$sql="SELECT * FROM organizer WHERE organizer LIKE '%".$searchq."%' OR profession LIKE '%".$searchq."%' OR staff_drecting LIKE '%".$searchq."%' OR Loactaion LIKE '%".$searchq."%' OR Document LIKE 
'%".$searchq."%' OR Date LIKE '%".$searchq."%'";
if ($result=mysqli_query($conn,$sql))
{
                                                                                                                
echo "<table border='1'>
<tr>
<th>organizer</th>
<th>profession</th>
<th>Staff Directing</th>
<th>Loactaion</th>
<th>Document</th>
<th>Date</th>


</tr>";
 
  
 while ($row=mysqli_fetch_row($result))
  {
  echo "<tr>";

  echo "<td>" . $row['1'] . "</td>";
  echo "<td>" . $row['2'] . "</td>";
  echo "<td>" . $row['3'] . "</td>";
  echo "<td>" . $row['4'] . "</td>";
  echo "<td>" . $row['5'] . "</td>";
  echo "<td>" . $row['6'] . "</td>";


  echo "</tr>";
  }
  
echo "</table>";
 mysqli_free_result($result);
  }
}
mysqli_close($conn);
?>
</body>
</html>