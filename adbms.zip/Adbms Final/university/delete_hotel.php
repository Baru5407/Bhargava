<?php 
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");

include('connection.php');


$sql = "DELETE FROM hotel  where id='".$_GET['id']."'";
$res=$conn->query($sql);
	
if($res===TRUE){
	header('Location:view_hotel.php');
}
else
{
echo $sql.''.$conn->error;

}
$conn->close();
?>