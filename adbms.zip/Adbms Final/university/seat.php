<?php 
include('connection.php'); 
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<style>
label{margin-left: 20px;}



</style>


<body>
<?php
include('main_header.php');
?>
<html>
<style>
input[type=text], select,input[type=date],input[type=time] {
       width: 95%;
    padding: 12px 14px;
    margin: 8px 20px;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box
}

input[type=submit] {
    width: 10%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left: 10px;
}

input[type=submit]:hover {
    background-color: #45a049;
}
#f{
	width:50%;
	background-color:#ccc;
}

</style>

<a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; position: absolute;"> </a>

<div id="f" class="col-md-offset-3">
<?php

  if(isset($_POST['sub1']))
{
    $sql = "INSERT INTO seat (e_time,Participant,Profession,Participant_Information,Staff_Directing,Location,Document,Date)
    VALUES('".$_POST["etime"]."','".$_POST["eid"]."','".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["contact"]."','".$_POST["email"]."','".$_POST["pname"]."','".$_POST["date11"]."')";
   
   $r=$conn->query($sql);
 $row=$conn->insert_id;
 if($r){
	 $qry="UPDATE seat set Row_No='$row' where id='$row'";
	  $conn->query($qry);
 ?>
 <h3>Success</h3>
<table class="table">
 <tr><td>Participant </td><td><?=$_POST["eid"]?></td></tr>
  <tr><td>Profession</td><td><?=$_POST["fname"]?></td></tr>
   <tr><td>Participant Information</td><td><?=$_POST["lname"]?></td></tr>
    <tr><td> Staff Directing Participants</td><td><?=$_POST["contact"]?></td></tr>
     <tr><td>Location and Venue</td><td><?=$_POST["email"]?></td></tr>
      <tr><td>Document To participant</td><td><?=$_POST["pname"]?></td></tr>
        <tr><td>Date </td><td><?=$_POST["date11"]?></td></tr>
		<tr><td>Time </td><td><?=$_POST["etime"]?></td></tr>
          <tr><td>Seat no  </td><td><?=$row?></td></tr>
          <tr><td colspan="2"><h3 style="text-align:center;"> $5 Recivied</h3></td></tr>
 </table






 
 <?php

}else{
  ?>
 <h3>Sorry</h3>
 <?php
 }
}else{?>



  <form action="" method="POST">
  <h3 style="padding:15px;">Form For the Participant Seat Allocation</h3>
  
   <label for="fname">Participant</label>
    <input type="text" id="eid" name="eid" placeholder="Participant "required >
	
    <label for="fname">Profession</label>
    <input type="text" id="fname" name="fname" placeholder="Profession" required >

    <label for="lname">Participant Information</label>
    <input type="text" id="lname" name="lname" placeholder="Participant Information" required>
	
	<label for="fname">Staff Directing Participants</label>
    <input type="text"  name="contact" placeholder="Staff Directing Participants" required>
	
	<label for="fname">Location and Venue</label>
    <input type="text"  name="email" placeholder="Location and Venue "required>
     
	  <label for="lname">Document To participant</label>
    <input type="text" name="pname" placeholder="Document To participant"required>
	
	 <label for="lname">Date</label>
    <input type="date" name="date11" placeholder="yyyy-mm-dd"required>
	
	<label for="lname">Time</label>
    <input type="time" name="etime" placeholder="Enter Time"required>
	
	 
    <input type="submit" name="sub1" value="Submit">
  </form>
  <?php }?>
</div>

</body>
</html>
