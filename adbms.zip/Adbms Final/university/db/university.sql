-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2017 at 05:21 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `username` varchar(2055) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `event_but` int(30) NOT NULL,
  `exp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `name`, `event_but`, `exp`) VALUES
(8, 'Education Fair', 1500, 1220),
(9, 'Manage Seating', 2600, 2500),
(10, 'Restaurant', 1993, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `id` int(255) NOT NULL,
  `Type_Of_Participant` varchar(50) NOT NULL,
  `Customers` varchar(2055) NOT NULL,
  `Payment` varchar(2055) NOT NULL,
  `Amount` int(50) NOT NULL,
  `Customer_info` varchar(2055) NOT NULL,
  `Menu` varchar(2055) NOT NULL,
  `Location` varchar(2055) NOT NULL,
  `Discount` varchar(2055) NOT NULL,
  `e_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`id`, `Type_Of_Participant`, `Customers`, `Payment`, `Amount`, `Customer_info`, `Menu`, `Location`, `Discount`, `e_id`) VALUES
(42, 'Participant', 'Raj', 'Net Banking', 30, 'DDN', '11', 'DDN', '12', 8),
(44, 'Student', 'SITA', 'Cash', 150, 'dddddd', '43', 'DDN', '12', 0),
(46, 'Student', 'Gita', 'Cash', 200, 'dddddd', '43', 'DDN', '12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE `organizer` (
  `id` int(255) NOT NULL,
  `organizer` varchar(2055) NOT NULL,
  `profession` varchar(500) NOT NULL,
  `staff_drecting` varchar(500) NOT NULL,
  `Loactaion` varchar(500) NOT NULL,
  `Document` varchar(2055) NOT NULL,
  `Date` varchar(250) NOT NULL,
  `e_time` varchar(200) NOT NULL,
  `e_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organizer`
--

INSERT INTO `organizer` (`id`, `organizer`, `profession`, `staff_drecting`, `Loactaion`, `Document`, `Date`, `e_time`, `e_id`) VALUES
(50, 'dd', 'sdsd', 'sdsd', 'dsd', 'dsd', '1234', '12', 9),
(51, '21', '121', '212', '121', '323', '32', '323', 0);

-- --------------------------------------------------------

--
-- Table structure for table `seat`
--

CREATE TABLE `seat` (
  `id` int(255) NOT NULL,
  `Participant` varchar(2055) NOT NULL,
  `Profession` varchar(2055) NOT NULL,
  `Participant_Information` varchar(2055) NOT NULL,
  `Staff_Directing` varchar(2055) NOT NULL,
  `Location` varchar(2055) NOT NULL,
  `Document` varchar(2055) NOT NULL,
  `Date` date NOT NULL,
  `Row_No` varchar(2055) NOT NULL,
  `e_time` varchar(250) DEFAULT NULL,
  `e_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seat`
--

INSERT INTO `seat` (`id`, `Participant`, `Profession`, `Participant_Information`, `Staff_Directing`, `Location`, `Document`, `Date`, `Row_No`, `e_time`, `e_id`) VALUES
(32, 'ffffd', 'dfdfd', 'dfdf', 'dfdf', 'dfdf', 'dfdf', '0000-00-00', '45', '12', 8),
(33, 'fg', 'gf', 'gfg', 'fg', 'fg', 'gf', '0000-00-00', '', '5454', 0),
(34, 'fg', 'gf', 'gfg', 'fg', 'fg', 'gf', '0000-00-00', '', '5454', 0),
(35, 'fg', 'gf', 'gfg', 'fg', 'fg', 'gf', '0000-00-00', '', '5454', 0),
(36, 'fg', 'gf', 'gfg', 'fg', 'fg', 'gf', '0000-00-00', '', '5454', 0),
(37, 'fg', 'gf', 'gfg', 'fg', 'fg', 'gf', '0000-00-00', '', '5454', 0),
(38, 'ddd', 'DDd', 'dddd', 'ff', 'dfd', '43', '2017-05-25', '38', '01:05', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seat`
--
ALTER TABLE `seat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `hotel`
--
ALTER TABLE `hotel`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `organizer`
--
ALTER TABLE `organizer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `seat`
--
ALTER TABLE `seat`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
