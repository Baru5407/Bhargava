<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      

</head>

<body>
<?php
include('main_header.php');

?>
<a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; position: absolute;"> </a>    <br><br><br>

<div class="container">
 <center> <h2>Event List</h2></center><br>
            
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Event Name</th>
        <th>Event Budget</th>
        <th>Event Expense</th>
        <th>View</th>
      </tr>
    </thead>
    <tbody>
	<?php $r=$conn->query("Select * from event");
	while($r1=$r->fetch_assoc()){
	?>
      <tr>
        <td><?=$r1['name']?></td>
        <td><?=$r1['event_but']?></td>
        <td><?=$r1['exp']?></td>
        <td><a href="amount_view.php?e_id=<?=$r1['event_id']?>" >View</a></td>
      </tr>
	<?php } ?>
    </tbody>
  </table>
</div>



      
   </body>
</html>