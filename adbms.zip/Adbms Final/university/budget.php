<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] )){
header("location:index.php");
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>
<div class="container">
<a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px; position: absolute;"> </a>    <br><br><br>
	<div class="row">
		<div class="col-md-4">
		</div>
		<div class="col-md-4" style="margin-top:100px">
			<form action="" method="POST">
			<h2>Update your budget </h2>
			Select Event Name<select type="text" class="form-control"name="e_name" required>
			<option value="">Select</option>
			<option>Education Fair</option>
			<option>Manage Seating</option>
			<option>Restaurant</option>
			</select>
			<br>
			Total Budget<input type="number" class="form-control" name="exp"  required><br>
				<br><center>
			<input type="submit" name="event1" class="btn btn-primary" value="Create Event"></center>
			
			
			</form>
		</div>
		<div class="col-md-4">
		</div>
	</div>
<?php if(isset($_POST['event1'])){
	
echo $sql="UPDATE event SET event_but='".$_POST['exp']."' WHERE name='".$_POST['e_name']."'";
$r=$conn->query($sql);
if($r===TRUE){
	header("location:main.php");
	$_SESSION['event_id']=$conn->insert_id;
}else{
	
	header("location:budget.php");
}
}?>

</div>
</body>
</html>
<?php } ?>