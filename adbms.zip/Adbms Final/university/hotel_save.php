 <?php include('connection.php'); ?>

<!Doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="description" content="$1">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="style.css">

<title>test</title>


</head>
<body>

 <?php

  if(isset($_POST['sub']))
{
    $sql = "INSERT INTO hotel (Type_Of_Participant,Customers,Payment,Amount,Customer_info,Menu,Location,Discount)
    VALUES      (  '".$_POST["Payment"]."','".$_POST["room"]."','".$_POST["payment"]."','".$_POST["Aname"]."','".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["diseases"]."','".$_POST["contact"]."')";

    $result = mysqli_query($conn,$sql);
	header('Location:view_hotel.php');
}