<?php
include('connection.php');
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
?>
<!DOCTYPE html>

<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
      
  
</head>
<body>
<?php
include('main_header.php');
?>

 <a href="main.php"><input  class='btn btn-default' name="sub1" value="Back" style="margin-top:23px;"> </a>
<div class="container-fluid">


 


<div class='row'><br>
 <div class='col-md-6 col-md-offset-3' >
<div id='form'>

<form action="" method="POST">
<table style="margin-bottom: 20px;
    width: 100%;">
<tr><td><input type="text" class= 'form-control' Placeholder="Search" name="search">
</td>
<td><input type="submit" class='btn' value="search" name="sub">
</td>
</tr>
</form>
</div>
<?php

if(isset($_POST['sub']))
{  
      $search_text=$_POST['search'];
	  $searchq=preg_replace('/[^^a-zA-Z0-9#@:_(),.!@"\/ ]/','',$search_text); 
      
        
$sql="SELECT * FROM organizer WHERE organizer LIKE '%".$searchq."%' OR profession LIKE '%".$searchq."%' OR staff_drecting LIKE '%".$searchq."%' OR Loactaion LIKE '%".$searchq."%' OR Document LIKE 
'%".$searchq."%' OR Date LIKE '%".$searchq."%'";
if ($result=mysqli_query($conn,$sql))
{
                                                                                                                
echo "<table class='table' style='background:white;'>
<tr>
<th>organizer</th>
<th>profession</th>
<th>Staff Directing</th>
<th>Loactaion</th>
<th>Document</th>
<th>Date</th>


</tr>";
 
  
 while ($row=mysqli_fetch_row($result))
  {
  echo "<tr>";

  echo "<td>" . $row['1'] . "</td>";
  echo "<td>" . $row['2'] . "</td>";
  echo "<td>" . $row['3'] . "</td>";
  echo "<td>" . $row['4'] . "</td>";
  echo "<td>" . $row['5'] . "</td>";
  echo "<td>" . $row['6'] . "</td>";


  echo "</tr>";
  }
  
echo "</table>";
 mysqli_free_result($result);
  }


}
else{

$result = mysqli_query($conn,"SELECT * FROM organizer");

echo "<table border='1' width='100%'>
<tr>

<th>Organizer</th>
<th>Profession</th>
<th>Staff Directing</th>
<th>Loactaion</th>
<th>Document</th>
<th>Date</th>
<th>Delete</th>
<th>Update</th>

</tr>";

while($row = mysqli_fetch_array($result))
  {
    echo "<tr>";
  
     echo "<td>" . $row['organizer'] . "</td>";
    echo "<td>" . $row['profession'] . "</td>";
    echo "<td>" . $row['staff_drecting'] . "</td>";
  echo "<td>" . $row['Loactaion'] . "</td>";
  echo "<td>" . $row['Document'] . "</td>";
 echo "<td>" . $row['Date'] . "</td>";  ?>
   
  <td><a href="delete_edu.php?id=<?=$row['id']?>">Delete</a></td>
  <td><a href="update_edu.php?id=<?=$row['id']?>">Update</a></td>
  <?php
  echo "</tr>";
  }
echo "</table>";

mysqli_close($conn);
}
?>

</div>
</div>
</div>


</body>
</html> 