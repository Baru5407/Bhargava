 <?php include('connection.php'); ?>
<!Doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="description" content="$1">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="style.css">

<title>University</title>


</head>
<body>

 <?php

  if(isset($_POST['sub1']))
{
    $sql = "INSERT INTO organizer (organizer,profession,staff_drecting,Loactaion,Document,Date)
    VALUES ('".$_POST["eid"]."','".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["contact"]."','".$_POST["org"]."','".$_POST["pname"]."')";

   // $result = mysqli_query($conn,$sql);
   $r=$conn->query($sql);
 header('Location:view_edu.php');
}