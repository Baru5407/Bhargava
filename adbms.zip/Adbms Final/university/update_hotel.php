<?php 
session_start();
if(!isset( $_SESSION['u_name'] ))
header("location:index.php");
include('connection.php');
?>
<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Universitys data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href= "css/bootstrap.min.css" rel = "stylesheet">
      <link href= "css/main.css" rel="stylesheet">
      <script src="js/jquery-2.1.3.js"></script>
      <script src="js/bootstrap.min.js"></script>
	  <script src="js/canvasjs.min.js"></script>
  

<style>
input[type=text], select {
    width: 95%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-left:20px;
}


label{
        margin-left: 30px;
    margin-top: 14px;
}

input[type=submit] {
    width: 20%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #3ec8d4;
}



.first{
    width: 700px;
    margin: 0 auto;
    background-color: #ccc;
}

</style>
</head>
<body>

<?php include('main_header.php');?>

<h3 style="text-align:center;">Update the Resturent Details</h3>

<div class="first">

<?php 
if(isset($_GET['id'])){
 $id=  $_GET['id'] ;
 $qry="SELECT * FROM hotel WHERE id ='$id' ";
 $q=$conn-> query($qry); 
 $r=$q-> fetch_assoc();
 ?>
  <form action="" method="POST">
  
  <label for="lname" >Type of Participant</label>
   
  
  <select name="type_of_participant" required>
  
    <option value="" selected disabled>Select Participant</option>
    <option >Organizer</option>
	 <option >Student</option>
	 <option >Customer</option>
    <option>Other</option>
	
   
    </select><br>
  
    <label for="fname">Name Of Participant</label>
    <input type="text" id="room" name="name_of_participant" value="<?=$r['Customers']?>"  placeholder="Participant" required >
   
     <label for="lname">Type of Payment</label>
   
	
	<select name="payment" required>
	  <option value="" selected disabled>Select Payment</option>
    <option value="Cheque">Cheque</option>
    <option value="Cash">Cash</option>
    <option value="Net Banking">Net Banking</option>
    <option value="Debit/Credit Card">Debit/Credit Card</option>
    </select><br>
	
    <label for="fname">Amount</label>
    <input type="text" id="fname" name="amount"  value="<?=$r['Amount']?>"  placeholder="Customer info or Participant"  required> 

	<label for="fname">Participant deitail</label>
    <input type="text" id="fname" name="fname"  value="<?=$r['Customer_info']?>"  placeholder="Customer info or Participant"  required>

    <label for="lname">Menu Being Displayed</label>
    <input type="text" id="lname" name="lname" value="<?=$r['Menu']?>"   placeholder="Menu Being Displayed" required >
	
	
	
	<label for="fname">Location and Venue</label>
     <input type="text" id="room" name="diseases" value="<?=$r['Location']?>"   placeholder="Location and Venue"required >
	
	<label for="fname">Discount provided</label>
    <input type="text" id="room" name="contact" value="<?=$r['Discount']?>"   placeholder="Discount provided"required >
	
		
		
     
 
    <input type="submit" name="sub1" value="Submit">
  </form>

  <?php }?>
</div>

</body>
</html>
<?php 
if(isset($_POST['sub1'])){
$sql = "UPDATE hotel SET Type_Of_Participant='".$_POST["type_of_participant"]."', Customers='".$_POST["name_of_participant"]."',Payment='".$_POST["payment"]."',Amount= '".$_POST["amount"]."',Customer_info='".$_POST["fname"]."',Menu='".$_POST["lname"]."',Location='".$_POST["diseases"]."',Discount='".$_POST["contact"]."' WHERE
id='".$_GET['id']."'";
$res=$conn->query($sql);
	
if($res===TRUE){

	header('Location:view_hotel.php');
}
else
{
echo $sql.''.$conn->error;

}
$conn->close();
}
?>
